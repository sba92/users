<?php
  require_once("dbconnection.php");
  require_once("functions.php");

  $title="Editar perfil";
  require_once("header.php");
  $activo=4;
  require_once("nav.php");
   if (!isLoged()){
       header("Location: index.php");
       exit();
   }
  
    $dbc = new DBConnection();

    $user = getUser($dbc);
    

    if($user->getTipo()!=1 && $_GET["id"]!=$user->getId()){
        header("Location: index.php");
        exit();
    }
    
    $edit_user = getUserById($dbc,$_GET["id"]);
    if($edit_user==null){
        header("Location: index.php");
        exit();
    }
    
    if (isset($_POST["submit"])){
      
      $stmt = $dbc->prepare("select * from user where id <> :id");
      $stmt->BindValue(":id", $edit_user->getId());
      $stmt->execute();
      $c=true;
      foreach($stmt as $row){
        if ($row["email"]==$_POST["email"] || $row["alias"]==$_POST["alias"]){
          $c=false;
        }
      }
      if ($c){
        $sql="update user set alias = :alias, email = :email, nombre = :nombre where id = :id";
        if (isset($_POST["password"]) && strlen($_POST["password"])>0){
          if($_POST["password"]==$_POST["password2"]){
            $pw=true;
            $sql="update user set alias = :alias, email = :email, contrasena = :contrasena, nombre = :nombre where id = :id";
          }
          else{
            $msg="Contraseñas no coinciden";
          }
        }
        
        if ($user->getTipo()==1){
          if($pw){
            $sql="update user set alias = :alias, email = :email, contrasena = :contrasena, type = :type, nombre = :nombre where id = :id";
          }
          else{
            $sql="update user set alias = :alias, email = :email, type = :type, nombre = :nombre where id = :id";
          }
        }
        $stmt = $dbc->prepare($sql);
        $stmt->BindValue(":id", $edit_user->getId());
        $stmt->BindValue(":alias", $_POST["alias"]);
        $stmt->BindValue(":email", $_POST["email"]);
        $stmt->BindValue(":nombre", (!isset($_POST["nombre"])||strlen($_POST["nombre"])==0?$_POST["email"]:$_POST["nombre"]));
        if ($pw){
          $stmt->BindValue(":contrasena", sha1($_POST["password"]));
        }
  
        if ($user->getTipo()==1){
          $stmt->BindValue(":type", (isset($_POST["checkadmin"])?"1":"2"));
        }
        $stmt->execute();
        $edit_user = getUserById($dbc,$edit_user->getId());
        header("Location: index.php");
        exit();
        
      }
      else{
        $msg="Se ha encontrado un usuario con este alias o email.";
      }
     
    }
    
    
    
?>

  <div class="container">
   <h1 class="my-4 text-center text-lg-left">Perfil</h1>
    <div class="row">
      <div class="col-md-12">
        <form method="POST" action="profile.php?id=<?php echo $_GET["id"]; ?>">
          <div class="form-group">
            <label for="exampleInputEmail1">Alias</label>
            <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="alias" placeholder="Introduce el alias" value="<?php echo $edit_user->getAlias(); ?>">
          </div>
          <div class="form-group">
            <label for="exampleInputEmail1">Nombre</label>
            <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="nombre" placeholder="Introduce el nombre" value="<?php echo $edit_user->getNombre(); ?>">
          </div>
          <div class="form-group">
            <label for="exampleInputEmail1">Correo electrónico</label>
            <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="email" placeholder="Introduce el email" value="<?php echo $edit_user->getCorreo(); ?>">
          </div>
          <div class="form-group">
            <label for="exampleInputPassword1">Contraseña</label>
            <input type="password" class="form-control" id="exampleInputPassword1" name="password" placeholder="Contraseña">
          </div>
          <div class="form-group">
            <label for="exampleInputPassword1">Repite la contraseña</label>
            <input type="password" class="form-control" id="exampleInputPassword1" name="password2" placeholder="Contraseña">
          </div>
          <?php
          
          if ($user->getTipo()==1){
              ?>
                  <div class="form-check">
                    <input type="checkbox" class="form-check-input" id="exampleCheck1" name="checkadmin" <?php echo ($edit_user->getTipo()==1?"checked":""); ?>>
                    <label class="form-check-label" for="exampleCheck1">Admin</label>
                  </div>
              <?php
          }
          ?>

          <button type="submit" class="btn btn-primary" name="submit">Editar perfil</button>
        </form>
        <?php
            if(isset($msg)){
                echo $msg;
            }
        ?>
      </div>
    </div>
  </div>
  
<?php
  require_once("footer.php");
?>