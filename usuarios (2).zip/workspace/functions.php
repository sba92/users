<?php
    require_once("usuario.php");
    function isLoged(){
        if(!isset($_SESSION))
            session_start();
        if (isset($_SESSION["id"])){
            return true;
        }
        return false;
    }
    
    function logout(){
        if(!isset($_SESSION))
            session_start();
        session_unset();
        session_destroy();
    }

    
    function getUserById($dbc,$id){
        $stmt=$dbc->prepare("select * from user where id = ?");
        $stmt->execute(array($id));
        $fila_user=$stmt->fetch();
        $user = new Usuario($fila_user["id"], $fila_user["email"], $fila_user["alias"], $fila_user["nombre"], $fila_user["contrasena"], $fila_user["activo"], $fila_user["type"], $fila_user["alta"]);
        return $user;
    }
    
    function getUser($dbc){
        if(isLoged()){
            return getUserById($dbc, $_SESSION["id"]);
        }
        return null;
    }
    
    function getMessageFormCode($code){
        switch ($code){
            case 1:
                return "Te hemos enviado un correo de activacion para activar tu cuenta";
            case 3:
                return "Cuenta activada correctamente";
            default:
                return "Unknown error";
        }
        
    }
    