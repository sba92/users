<?php

  require_once("functions.php");
  require_once("dbconnection.php");
  
  if (isLoged()){
    header("Location: index.php");
    exit();
  }
  
  $title="Login - SBA";
  require_once("header.php");
  $activo=2;
  require_once("nav.php");
  
  
  //login
  if (isset($_POST["submit"])){
    $dbc = new DBConnection();
    
    $stmt = $dbc->prepare("select * from user where email = ? and contrasena = ?");
    $stmt->execute(array($_POST["email"], sha1($_POST["password"])));
    
    //si no existe este usuario
    if ($stmt->rowCount() == 1){
        $user = $stmt->fetch();
        $_SESSION["id"] = $user["id"];
        $_SESSION["user"] = $user["alias"];//Dejo el alias porque a veces solo nos hace falta este dato del usuario y acceder a db por 1 solo dato es tonteria

        header("Location: index.php");
        exit();
    }
    else{
        $msg="<p>Error, usuario o contraseña incorrectos.</p>";
    }
  }
  
?>
  
  <div class="container">
    <h1 class="my-4 text-center text-lg-left">Login</h1>
    <?php
      if(isset($_GET["msg"])){
        ?>
        <div class="alert alert-success" role="alert">
         <?php echo getMessageFormCode($_GET["msg"]); ?>
        </div>
        <?php
      }
    ?>
    <div class="row">
      <div class="col-md-12">
        <form method="POST" action="login.php">
          <div class="form-group">
            <label for="exampleInputEmail1">Email address</label>
            <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="email" placeholder="Enter email">
          </div>
          <div class="form-group">
            <label for="exampleInputPassword1">Password</label>
            <input type="password" class="form-control" id="exampleInputPassword1" name="password" placeholder="Password">
          </div>
          <button type="submit" class="btn btn-primary" name="submit">Login</button>
          <a href="register.php"><button type="button" class="btn btn-primary">Registro</button></a>
        </form>
        <?php
            if(isset($msg)){
                echo $msg;
            }
        ?>
      </div>
    </div>
  </div>
  
<?php
  require_once("footer.php");
?>