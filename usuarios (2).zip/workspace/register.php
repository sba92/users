<?php
  require_once("functions.php");
  require_once("dbconnection.php");
 // require_once ('phpmailer/class.phpmailer.php');
  require 'clases/vendor/autoload.php';
  
  if(isLoged()){
    header("Location: index.php");
    exit();
  }
  
  $title="Registro - SBA";
  require_once("header.php");
  $activo=3;
  require_once("nav.php");
  
  if (isset($_POST["submit"])){
      if ($_POST["password"]!=$_POST["password2"]){
          $msg="<p>Error, las contraseñas no coinciden.</p>";
      }
      if(!isset($msg)){
          $dbc = new DBConnection();
          
          $stmt = $dbc->prepare("select * from user where email = ? or alias = ?");
          $stmt->execute(array($_POST["email"], $_POST["alias"]));
            
          //si no existe este usuario
          if ($stmt->rowCount() <= 0){
              //hago una sentencia preparada, cojo lo que me llega por post y lo asocio a la sentencia, por ultimo ejecuto
              $stmt = $dbc->prepare("insert into user(alias,email,contrasena,nombre) values ( :alias, :email, :contrasena, :nombre )");
              $stmt->BindValue(":alias", $_POST["alias"]);
              $stmt->BindValue(":email", $_POST["email"]);
              $stmt->BindValue(":contrasena", sha1($_POST["password"]));
              $stmt->BindValue(":nombre", (!isset($_POST["nombre"])||strlen($_POST["nombre"])==0?$_POST["email"]:$_POST["nombre"]));
              $stmt->execute();
              //con la conexion hago lastInsertId() 
              
              $id = $dbc->getLink()->lastInsertId();
              
             /* 
              $stmt = $dbc->prepare("select * from user where email = :email");
              $stmt->BindValue(":email", $_POST["email"]);
              $stmt->execute();
              $user = $stmt->fetch();
              $token="abcdefghijklmñnopqrstuvwxyz0123456789";
              $token=str_shuffle($token);
              */

              
            /*
            para tenerlo de dos formas hecho
              $stmt = $dbc->prepare("insert into user(alias,email,contrasena,nombre) values ( ?, ?, ?, ? )");
              $stmt->BindValue(1, $_POST["alias"]);
              $stmt->BindValue(2, $_POST["email"]);
              $stmt->BindValue(3, sha1($_POST["password"]));
              $stmt->BindValue(4, $_POST["nombre"]);
              $stmt->execute();
            */
            /*
              $mail = new PHPMailer();
      				$mail->Host = "smtp.gmail.com:465";
      				$mail->Username = "pepeizv92@gmail.com";
      				$mail->Password = "IZv12345678";
      				$mail->From = "pepeizv92@gmail.com";
      				$mail->AddAddress($_POST["email"]);*/
      
              /*$origen = "pepeizv92@gmail.com";
              $alias = "Curso DWES IZV";
              $destino = "pepeizv92@gmail.com";
              $asunto = "Prueba de correo";
              $mensaje = "¿Llegará?";
              */
             /* $cliente = new Google_Client();
      				$mail->Subject = "Activación de cuenta de ".$_POST["alias"];
      				$mail->Body = "Para activar tu cuenta entra en <a href=\"https://usuarios-sba92.c9users.io/activar.php?id=".$user["id"]."&token=".$token."\">";
      				$mail->IsHTML(true);*/
      			/*	if(!$mail->Send())
      				{
      					$success = "Ocurrio un error!";
      				   //echo "Error: " . $mail->ErrorInfo;
      				}
      				else
      				{
      					$success = "Mensaje enviado!";
      				}*/
      				$token="abcdefghijklmñnopqrstuvwxyz0123456789";
              $token=sha1(str_shuffle($token));
              
              $stmt = $dbc->prepare("insert into activacion values (null,?,?)");
              $stmt->execute(array($id,$token));
              
      				$origen = "pepeizv92@gmail.com";
              $alias = "Curso DWES IZV";
              $destino = $_POST["email"];
              $asunto = "Prueba de correo";
              $mensaje = "Para activar tu cuenta entra en <a href=\"https://usuarios-sba92.c9users.io/activar.php?id=".$id."&token=".$token."\">";
              $cliente = new Google_Client();
              
              
              
              $cliente->setApplicationName('usuario');
              $cliente->setClientId('954652568311-qouj8o5cjhtfqvssginctnqrldv0bava.apps.googleusercontent.com');
              $cliente->setClientSecret('vxKUErtrCHXUEud6CslftKMW');
              
              $cliente->setAccessToken(file_get_contents('token.conf'));
              if ($cliente->getAccessToken()) {
                  $service = new Google_Service_Gmail($cliente);
                  try {
                      $mail = new PHPMailer\PHPMailer\PHPMailer();
                      $mail->CharSet = "UTF-8";
                      $mail->From = $origen;
                      $mail->FromName = $alias;
                      $mail->AddAddress($destino);
                      $mail->AddReplyTo($origen, $alias);
                      $mail->Subject = $asunto;
                      $mail->Body = $mensaje;
                      $mail->preSend();
                      $mime = $mail->getSentMIMEMessage();
                      $mime = rtrim(strtr(base64_encode($mime), '+/', '-_'), '=');
                      $mensaje = new Google_Service_Gmail_Message();
                      $mensaje->setRaw($mime);
                      $service->users_messages->send('me', $mensaje);
                      echo "Correo enviado correctamente";
                  } catch (Exception $e) {
                      echo ("Error en el envío del correo: " . $e->getMessage());
                  }
              } else {
                  echo "No conectado con gmail";
              }


             header("Location: login.php?msg=1&email=".$user["email"] );
             exit();
          }
          else{
              $msg="<p>Error, ese usuario ya existe.</p>";
          }
          
      }
  }
  
?>
  
  <div class="container">
    <h1 class="my-4 text-center text-lg-left">Registro</h1>
    <div class="row">
      <div class="col-md-12">
        <form method="POST" action="register.php">
          <div class="form-group">
            <label for="exampleInputEmail1">Alias*</label>
            <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="alias" placeholder="Introduce el alias" required>
          </div>
          <div class="form-group">
            <label for="exampleInputEmail1">Nombre</label>
            <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="nombre" placeholder="Introduce el nombre">
          </div>
          <div class="form-group">
            <label for="exampleInputEmail1">Correo electrónico*</label>
            <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="email" placeholder="Introduce el email" required>
          </div>
          <div class="form-group">
            <label for="exampleInputPassword1">Contraseña*</label>
            <input type="password" class="form-control" id="exampleInputPassword1" name="password" placeholder="Contraseña" required>
          </div>
          <div class="form-group">
            <label for="exampleInputPassword1">Repite la contraseña*</label>
            <input type="password" class="form-control" id="exampleInputPassword1" name="password2" placeholder="Contraseña" required>
          </div>
          
          <button type="submit" class="btn btn-primary" name="submit">Registrarse</button>
          <a href="login.php"><button type="button" class="btn btn-primary">Cancelar</button></a>
        </form>
        <?php
            if(isset($msg)){
                echo $msg;
            }
        ?>
        
      </div>
    </div>
  </div>
  
<?php
  require_once("footer.php");
?>