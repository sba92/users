<?php
/*
session_start();
require_once '../clases/vendor/autoload.php';
$cliente = new Google_Client();
$cliente->setApplicationName('usuario');
$cliente->setClientId('954652568311-qouj8o5cjhtfqvssginctnqrldv0bava.apps.googleusercontent.com');
$cliente->setClientSecret('vxKUErtrCHXUEud6CslftKMW');
$cliente->setRedirectUri('https://usuarios-sba92.c9users.io/gmail/obtenercredenciales.php');
$cliente->setScopes('https://www.googleapis.com/auth/gmail.compose');
$cliente->setAccessType('offline');
if (isset($_GET['code'])) {
    $cliente->authenticate($_GET['code']);
    $_SESSION['token'] = $cliente->getAccessToken();
    $archivo = "token.conf";
    $fh = fopen($archivo, 'w') or die("error");
    fwrite($fh, json_encode($cliente->getAccessToken()));
    fclose($fh);
    header("Location: finalizartoken.php?code=" . $_GET['code']);
}