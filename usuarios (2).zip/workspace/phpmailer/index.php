<?php
header('Location: https://www.alecsurinstalaciones.es');
exit;
?>