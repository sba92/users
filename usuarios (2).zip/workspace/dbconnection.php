<?php

    define("DB_HOST", "localhost");
    define("DB_USER", "sba92");
    define("DB_PASS", "");
    define("DB_NAME", "controlusuarios");
    
    class DBConnection{
        
        private $host = DB_HOST;
        private $db = DB_NAME;
        private $user = DB_USER;
        private $pass = DB_PASS;
        private $link;
        private $error=null;
        
        
        public function __construct(){
            $options = array(
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
            );
            $dsn="mysql:host=" . $this->host . ";dbname=" . $this->db . ";";
            
            try{
                $this->link=new PDO($dsn, $this->user, $this->pass, $options);
            }
            catch(PDOException $ex){//Si no conecta guardo en error el mensaje de error con el metodo getMessage de PDOException
                $this->error=$ex->getMessage();
            }
            
        }
        
        public function __toString(){
            return $this->error;
        }
        public function getLink(){
            return $this->link;
        }
        
        public function __destruct(){
            $link=null;
        }
        
        public function getError(){
            return $this->error;
        }
        //para ejecutar cualquier tipo de sentencia preparada
        public function prepare($sql){
            return $this->link->prepare($sql);
        }
        //para insert update delete de forma directa
        public function runQuery($query){
            try{
                return $this->link->exec($query);
            }
            catch(PDOException $ex){
                $this->error=$ex->getMessage();
                return "Error";
            }
        }
        //para ejecutar un select de forma directa, mejor no usar
        public function runSelect($query){
            try{
                $sentencia = $this->link->query($query);
                $sentencia->setFetchMode(PDO::FETCH_ASSOC);
                return $sentencia;
            }
            catch(PDOException $ex){
                $this->error=$ex->getMessage();
                return "Error";
            }
        }
    }
    
?>