<?php
  require_once("dbconnection.php");
  require_once("functions.php");

  $title="Inicio";
  require_once("header.php");
  $activo=1;
  require_once("nav.php");
  
  

  
  $dbc = new DBConnection();
  if (isLoged()) {
    $user = getUser($dbc);
    if(isset($_GET["delete"])){
      $stmt=$dbc->prepare("delete from user where id = ?");
      if($_GET["delete"]==$user->getId()){
        $stmt->execute(array($_GET["delete"]));
        logout();
      ?>
        <div class="container">
            <h1 class="my-4 text-center text-lg-left">Gestion de usuarios</h1>
            <div class="alert alert-success" role="alert">
             <?php echo "Tu cuenta se ha eliminado correctamente!"; ?>
            </div>
        </div>
      <?php
        exit();
      }
      else if($user->getTipo()==1){
        $stmt->execute(array($_GET["delete"]));
        $msg = "Eliminado correctamente";
      }
    }
    
    if (isset($_POST["marcado"]) && $user->getTipo()==1){
      $stmt=$dbc->prepare("delete from user where id = :id");
      foreach($_POST["marcado"] as $v){
        $stmt->execute(array(":id" => $v));
        if ($v == $user->getId()){
          logout();
        }
      }
    }
    
    $stmt=$dbc->prepare("select * from user");
    $stmt->execute();

  }
  
?>

  <div class="container">
    <?php
    
    if(isLoged()){
      ?>
      <h1 class="my-4 text-center text-lg-left">Welcome, <?php echo $user->getNombre(); ?></h1>
      <?php
    }
    else{
      ?>
      <h1 class="my-4 text-center text-lg-left">Gestión Usuarios</h1>
      <?php
    }
    
    ?>
    
    
    <div class="row">
      <?php
        if (isLoged()){
            if ($user->getActivo()==0){
                  ?>
                    <div class="col-md-12">
                      <h1>Necesitas activar tu cuenta antes de poder acceder a esta sección</h1>
                    </div>
                  <?php
            }
            else {
              if (isset($_GET["msg"])){
                $msg=getMessageFormCode($_GET["msg"]);
              }
              if(isset($msg)){
                ?>
                <div class="alert alert-success" role="alert">
                 <?php echo $msg; ?>
                </div>
                <?php
              }
    ?>
                    <form method="POST" action="index.php">
                    <table class="table">
                      <thead>
                        <tr>
                          <th scope="col">#</th>
                          <th scope="col">Nombre</th>
                          <th scope="col">Correo</th>
                          <th scope="col">Alias</th>
                          <th scope="col">Activo</th>
                          <th scope="col">Administrador</th>
                          <th scope="col">Fecha alta</th>
                          <th scope="col">Borrar</th>
                          <th scope="col">Editar</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                        
                        foreach($stmt as $row){
                          echo "<tr>";
                          echo "<td><input type=\"checkbox\" name=\"marcado[]\" value=\"".$row["id"]."\"/></td>";
                          echo "<td>".$row["nombre"]."</td>";
                          echo "<td>".$row["email"]."</td>";
                          echo "<td>".$row["alias"]."</td>";
                          echo "<td><i class=\"material-icons\">".($row["activo"]==0?"close":"done")."</i></td>";
                          echo "<td><i class=\"material-icons\">".($row["type"]==1?"done":"close")."</i></td>";
                          echo "<td>".$row["alta"]."</td>";
                          echo "<td>".($user->getTipo()==1 || $row["id"]==$user->getId()?"<a href=\"?delete=".$row["id"]."\"><button type=\"button\" class=\"btn btn-primary\">Borrar</button></a>":"")."</td>";
                          echo "<td>".($user->getTipo()==1 || $row["id"]==$user->getId()?"<a href=\"profile.php?id=".$row["id"]."\"><button type=\"button\" class=\"btn btn-primary\">Editar</button>":"")."</td>";
                          echo "</tr>";
                        }
                        
                        ?>
                      </tbody>
                    </table>
                   <?php 
                   
                   if ($user->getTipo()==1){
                     ?>
                     <button class="btn btn-primary">Borrar selecionados</button>
                     <?php
                   }
                   
                   ?>
                    
                    </form>
                 <?php
            }
        }
        else{
          if (isset($_GET["msg"])){
            ?>
                    <div class="col-md-12">
                      <h1><?php echo getMessageFormCode($_GET["msg"]);?></h1>
                    </div>
            <?php
          }
          else{
            
          
          ?>
            <div class="col-md-12">
              <h1>Necesitas conectarte para ver nuestra web</h1>
            </div>
          <?php
          }
        }
      ?>
    </div>
  </div>
  
<?php
  require_once("footer.php");
?>