<?php


if(isset($_GET["id"]) && isset($_GET["token"])){
    require_once("dbconnection.php");




    $dbc= new DBConnection();
    $stmt=$dbc->prepare("select * from activacion where user = ? and token = ?");
    $stmt->execute(array($_GET["id"],$_GET["token"]));
    
    if ($stmt->rowCount()==1){
        $dbc->prepare("update user set activo = 1 where id = ?")->execute(array($_GET["id"]));
        $dbc->prepare("delete from activacion where user = ? and token = ?")->execute(array($_GET["id"],$_GET["token"]));
        header("Location: index.php?msg=3");
    }
    else{
        echo "Activación desconocida";
    }
    
}

